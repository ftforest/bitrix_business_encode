<?php


$MESS["FTDEN45_EDADEALEXPJSON_TAB_SETTINGS"] = "Основные настройки";
$MESS["FTDEN45_EDADEALEXPJSON_EXPORT_EDADEAL"] = "Export Json Edadeal.ru";
$MESS["FTDEN45_EDADEALEXPJSON_FIELD_NAME_FILE_EXPORT"] = "Задайте имя файла json\n(если не задан то имя будет file.json)\n(Файл находиться по пути upload/edadeal_json/file.json )";
$MESS["FTDEN45_EDADEALEXPJSON_FIELD_PRODUCT_URL"] = "Задайте ссылку на элементы инфоблока Товары (символьный код: ed_products)";