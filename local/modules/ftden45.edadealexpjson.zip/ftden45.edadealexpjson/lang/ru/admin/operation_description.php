<?
/**
 * Created by PhpStorm
 * User: Sergey Pokoev
 * www.pokoev.ru
 * @ Академия 1С-Битрикс - 2015
 * @ academy.1c-bitrix.ru
 */
$MESS["OP_NAME_POKOEV_ORM_READ"] = "Чтение данных";
$MESS["OP_DESC_POKOEV_ORM_READ"] = "";
$MESS["OP_NAME_POKOEV_ORM_SETTINGS"] = "Редактирование настроек";
$MESS["OP_DESC_POKOEV_ORM_SETTINGS"] = "";
$MESS["OP_NAME_POKOEV_ORM_EDIT"] = "Доступ к редактированию ORM сущностей";
$MESS["OP_DESC_POKOEV_ORM_EDIT"] = "";

