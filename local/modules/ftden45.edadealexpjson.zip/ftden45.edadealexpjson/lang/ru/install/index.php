<?
/**
 * Created by PhpStorm
 * User: Sergey Pokoev
 * www.pokoev.ru
 * @ Академия 1С-Битрикс - 2015
 * @ academy.1c-bitrix.ru
 */
$MESS["FTDEN45_EDADEALEXPJSON_MODULE_NAME"] = "Модуль Экспорта в формате Edadeal";
$MESS["FTDEN45_EDADEALEXPJSON_MODULE_DESC"] = "Модуль Экспорта в формате Edadeal";
$MESS["FTDEN45_EDADEALEXPJSON_PARTNER_NAME"] = "ftden45";
$MESS["FTDEN45_EDADEALEXPJSON_PARTNER_URI"] = "http://ftden45.ru/";

$MESS["FTDEN45_EDADEALEXPJSON_DENIED"] = "Доступ закрыт";
$MESS["FTDEN45_EDADEALEXPJSON_READ_COMPONENT"] = "Доступ к компонентам";
$MESS["FTDEN45_EDADEALEXPJSON_WRITE_SETTINGS"] = "Изменение настроек модуля";
$MESS["FTDEN45_EDADEALEXPJSON_FULL"] = "Полный доступ";

$MESS["FTDEN45_EDADEALEXPJSON_INSTALL_TITLE"] = "Установка модуля";
$MESS["FTDEN45_EDADEALEXPJSON_INSTALL_ERROR_VERSION"] = "Версия главного модуля ниже 14. Не поддерживается технология D7, необходимая модулю. Пожалуйста обновите систему.";

#работа с .settings.php
$MESS["FTDEN45_EDADEALEXPJSON_INSTALL_COUNT"] = "Количество установок модуля: ";
$MESS["FTDEN45_EDADEALEXPJSON_UNINSTALL_COUNT"] = "Количество удалений модуля: ";

$MESS["FTDEN45_EDADEALEXPJSON_NO_CACHE"] = 'Внимание, на сайте выключено кеширование!<br>Возможно замедление в работе модуля.';
#работа с .settings.php
?>